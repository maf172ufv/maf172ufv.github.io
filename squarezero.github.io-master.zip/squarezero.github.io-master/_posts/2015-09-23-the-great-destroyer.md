---
title: The Great Destroyer
layout: post
background: https://cdna.artstation.com/p/assets/images/images/002/187/704/large/teun-van-der-zalm-ncu001-13d.jpg
subtitle: Time to meet the creator.
artist: artstation.com/teunvanderzalm
---

He was staring into absolute darkness.Nothing else, just plain void. There was no sound, no smell, no sight, no sense of  touch either. He felt weightless, spaceless. But behind him was something he didn't want to see. He knew he had finally reached his 'destiny'. And he was scared to see what the creator looked like.

He finally mustered the courage to turn. He turned.He turned, and experienced the ineffable. Before him was a figure, glowing in the dark.He realised this was outer space, and the figure stood on a one dimensional platform. Stood? No. It was moving violently, shaking all its parts. Now he could make out the shape. It resembled a human form. But gosh, it was atleast a million times bigger than him, and he could see the eyes too. The eyes were flaming red, lava pouring out from them. Its glow blinded him.Its hair flew all over the universe. And the whole universe started shaking with its moves, resonating with his steps. Was he dancing ? What was happening?

Accompanying the dance was noise he couldn't bear. The sounds were absolutely disjoint glitches of varying kinds, too loud and shrill that he started bleeding and screaming. But he caught the rhythm soon and suddenly, they all appeared to be in perfect sync. The sound was surreal, the perfect embodiment of art. It was music.It was music at its purest form. He couldn't believe what was happening. Since he knew he was in his mind, was it a virus? That was what pathogens looked like?
No. Was it a sub-atomic particle? Was it God ? Was it god? Was it god? It was god? That was god !

Suddenly he was transported with all kinds of emotions.He was scared and overwhelmed,he was laughing and crying,he was calm and angry and ecstatic; and joined the figure which continued to dance with fury, joy and vigor while the god music continued to blare. The music reached its crescendo now.He felt weightless, he felt invincible dancing and jumping like that.Tears stormed down from his eyes. He knew what he wanted to do. He wanted to 'surrender' himself to god. He wanted to die.Merge with god.Become a part of him. Is this what the vedas talked about? He was a rational person, but he couldn't believe what was happening.

All his senses now worked in unison and gave him the unified sense. The one only attainable by god. He grew in space, and time. He was turning into god. He could see the space, the earth, its people, the zillion other planets thriving with life, which appeared so close to earth. He could see the beginning, he could see the end. He could see the beings, calling out to him. He could see the infinite and the infinitesimal. All through his mind.
<br/>He turned into the Great Destroyer.