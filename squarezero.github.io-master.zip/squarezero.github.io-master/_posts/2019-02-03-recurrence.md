---
title: Recurrence
background: https://cdnb.artstation.com/p/assets/images/images/007/095/957/large/mark-chang-lab3.jpg
layout: post
subtitle: A minion breaks the code
artist: artstation.com/equinoz
---

They work all day, they work all night.
<br/>They look at you, they send you thoughts.
<br/>They just want to see you think.
<br/>They want to know what goes on in that little brain of yours when the spark happens.

Why, we don't know; but we do know that it's important for them.
<br/>They work all the time relentlessly, not a mistake made because it's simply not in their design.

But every now and then, when the chief turns out of phase, an impish minion picks a memory from a run that already happened and feeds it back to you.
<br/>That crazy bugger just likes to watch you freak out.
<br/>He looks at your brain with awe, the way the alarms go haywire inside.

What has he done!
<br/>He just likes to tip us off, and watch us remain helpless.
<br/>That little devil likes that fleeting anguish the barrage of cross firing neurons cause.