---
title: Love Story - Chapter 1
background: https://cdna.artstation.com/p/assets/images/images/003/981/916/large/alena-aenami-atlast2k2.jpg?1479156464
layout: post
artist: artstation.com/aenamiart
subtitle: Infatuation
---

'Is she actually looking at me?'
<br/>
'Oh my God, really?'
<br/>
'How is this happening?'
<br/>
'I AM INVINCIBLE.'
<br/>
My brain was weaving dozens of non-sensical lines, and I was blurting out all of them. Of course, to myself. I was sitting alone.
<br/>
It must've been adrenaline. Why not?
<br/>
I was shifting about in my chair, fiddling with my fingers, staring intensely at the beer infront of me, and stealing a glance at her every quarter of a minute.
<br/>
The unnerving thing was that every third time she'd be looking at me. And we would share a moment of perfect oblivion, looking into each other's eyes. Then I'd turn away hastily and mutter some more gibberish.
<br/>
'Definitely my pattern. Yes.'
<br/>
I had discovered with my experience that I always fall for a particular set of women. All of them fit a particular pattern. A pattern of alignments.
<br/>
'The theory of features and alignments!'. That was the name I'd given it. I'm generally shy around girls, and if they belong to my pattern, it's almost like I'm scared of them.
<br/>
My animal instincts were in full effect, forcing smiles on my face, and thrusting my hands to do anything that might prove my might to my lady. 
<br/>
I was trying hard to curb them, partially succeeding.
<br/>
She was accompanied by some very chic people like herself, but she didn't seem to be interested at all, only faking her laughs to their chatter. Instead, she was interested in the handsome man sitting two tables to the left.
<br/>
A forgotten track had resurfaced in my head, and my heart was pounding too fast. I couldn't take it anymore, I just had to do something.
<br/>
I managed a simple smile. Heck, that's the best I could do. I quickly turned away from her in disappointment, but looked back quickly to see her smile in reply.
<br/>
Heavens! I grinned and looked away again. She grinned too. There! I could see the perfect pattern.
<br/>
Just as I was thinking of asking her to come over to my table, a stupid friend of mine interrupted our thing that we had, and took me away with him.
<br/>
I could not say anything to him; I just looked back and raised my hand, half waving at her. She smiled and waved back with a smile, as I turned and walked away. 
<br/>
Somehow, just somehow, at that point, I had a feeling that I'd find her again after that night.
And I did.